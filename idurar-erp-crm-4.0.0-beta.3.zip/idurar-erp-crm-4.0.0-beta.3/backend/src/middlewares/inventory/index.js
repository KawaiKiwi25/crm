const generateUniqueNumber = require('../inventory/generateUniqueNumber');

module.exports = {
  generateUniqueNumber,
};
